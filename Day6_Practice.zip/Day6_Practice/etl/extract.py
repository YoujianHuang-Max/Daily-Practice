import pandas as pd
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parents[1] / "data"


def extract_patients():
    return pd.read_csv(DATA_DIR / "patients.csv")


def extract_encounters():
    return pd.read_csv(DATA_DIR / "encounters.csv")


def extract_lab_results():
    return pd.read_csv(DATA_DIR / "lab_results.csv")