import pandas as pd


def standardize_columns(df: pd.DataFrame) -> pd.DataFrame:
    df.columns = (
        df.columns
        .str.strip()
        .str.lower()
        .str.replace(" ", "_")
    )
    return df


def clean_patients(df: pd.DataFrame) -> pd.DataFrame:
    df = standardize_columns(df)
    df["birth_date"] = pd.to_datetime(df["birth_date"], errors="coerce")
    return df


def clean_encounters(df: pd.DataFrame) -> pd.DataFrame:
    df = standardize_columns(df)
    df["visit_date"] = pd.to_datetime(df["visit_date"], errors="coerce")
    return df


def clean_lab_results(df: pd.DataFrame) -> pd.DataFrame:
    df = standardize_columns(df)
    df["test_date"] = pd.to_datetime(df["test_date"], errors="coerce")
    df["lab_test"] = df["lab_test"].str.upper()
    return df