import pandas as pd
from pathlib import Path

DATA_DIR = Path(__file__).parent / "data"
DATA_DIR.mkdir(exist_ok=True)

# ---- patients.csv ----
patients = pd.DataFrame({
    "patient_id": [1, 2, 3],
    "birth_date": ["1980-01-01", "1990-05-20", "1975-08-15"],
    "gender": ["M", "F", "M"]
})
patients.to_csv(DATA_DIR / "patients.csv", index=False)

# ---- encounters.csv ----
encounters = pd.DataFrame({
    "encounter_id": [101, 102, 103, 104],
    "patient_id": [1, 1, 2, 3],
    "visit_date ": ["2024-01-10", "2024-02-15", "2024-03-20", "2024-04-05"],
    "encounter_type": ["Checkup", "Emergency", "Checkup", "Checkup"]
})
encounters.to_csv(DATA_DIR / "encounters.csv", index=False)

# ---- lab_results.csv ----
lab_results = pd.DataFrame({
    "lab_result_id": [1001, 1002, 1003, 1004],
    "encounter_id": [101, 101, 102, 103],
    "lab_test": ["Blood Sugar", "Cholesterol", "Blood Pressure", "Blood Sugar"],
    "result_value": [5.5, 180, 120, 6.0],
    "test_date": ["2024-01-11", "2024-02-16", "2024-03-21", "2024-04-06"],
})
lab_results.to_csv(DATA_DIR / "lab_results.csv", index=False)

print("Raw CSV data generated in ./data/")