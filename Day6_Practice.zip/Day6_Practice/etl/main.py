from extract import (
    extract_patients,
    extract_encounters,
    extract_lab_results
)
from transform import (
    clean_patients,
    clean_encounters,
    clean_lab_results
)
from load import load_dataframe


def run_etl():
    patients = clean_patients(extract_patients())
    encounters = clean_encounters(extract_encounters())
    labs = clean_lab_results(extract_lab_results())

    load_dataframe(patients, "dim_patient")
    load_dataframe(encounters, "fact_encounter")
    load_dataframe(labs, "fact_lab_result")


if __name__ == "__main__":
    run_etl()